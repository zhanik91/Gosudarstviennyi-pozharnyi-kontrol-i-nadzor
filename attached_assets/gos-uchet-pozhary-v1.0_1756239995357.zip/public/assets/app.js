
const $ = (s)=>document.querySelector(s);
const API = {
  async req(path, opts={}){
    const token = localStorage.getItem("token");
    opts.headers = opts.headers || {};
    if (token) opts.headers.Authorization = "Bearer "+token;
    const r = await fetch(path, opts);
    if (!r.ok) throw new Error(await r.text() || ("HTTP "+r.status));
    const ct = r.headers.get("content-type")||"";
    if (ct.includes("application/json")) return r.json();
    return r.text();
  },
  login: (email,password)=> API.req("/api/auth/login",{method:"POST", headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})}),
  whoami: ()=> API.req("/api/auth/whoami"),
  enums: ()=> API.req("/api/enums"),
  incidents: (period, includeChildren)=> API.req(`/api/incidents?period=${encodeURIComponent(period||'')}&includeChildren=${includeChildren?'true':'false'}`),
  addIncident: (payload)=> API.req("/api/incidents",{method:"POST", headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)}),
  delIncident: (id)=> API.req("/api/incidents/"+id, { method:"DELETE" }),
  reports: (p, tree)=> API.req(`/api/reports?period=${encodeURIComponent(p||'')}&tree=${tree?'true':'false'}`),
  validate: (p)=> API.req(`/api/validate?period=${encodeURIComponent(p||'')}`),
  sendPackage: (period)=> API.req("/api/packages/send",{method:"POST", headers:{'Content-Type':'application/json'}, body: JSON.stringify({period})}),
  inbox: (period)=> API.req(`/api/packages/inbox?period=${encodeURIComponent(period||'')}`),
  approve: (packageId)=> API.req("/api/packages/approve",{method:"POST", headers:{'Content-Type':'application/json'}, body: JSON.stringify({packageId})}),
  returnPkg: (packageId, reason)=> API.req("/api/packages/return",{method:"POST", headers:{'Content-Type':'application/json'}, body: JSON.stringify({packageId, reason})})
};
let USER = null;
function setTab(name){
  document.querySelectorAll(".tab").forEach(t=>t.classList.add("hidden"));
  const el = document.querySelector("#tab-"+name);
  if (el) el.classList.remove("hidden"), el.classList.add("active");
  document.querySelectorAll(".tab-btn").forEach(b=> b.classList.remove("active"));
  const b = document.querySelector(`.tab-btn[data-tab="${name}"]`);
  if (b) b.classList.add("active");
}
function toggleBlocks(){
  const t = document.querySelector("#event_type").value;
  document.querySelector("#block-fire").classList.toggle("hidden", !(t==="fire"||t==="steppe_fire"));
  document.querySelector("#block-ssg").classList.toggle("hidden", t!=="nonfire");
  document.querySelector("#block-steppe").classList.toggle("hidden", !(t==="steppe_fire"||t==="steppe_smolder"));
  document.querySelector("#block-co").classList.toggle("hidden", t!=="co_nofire");
}
document.addEventListener("change",(e)=>{ if (e.target && e.target.id==="event_type") toggleBlocks(); });
async function boot(){
  try {
    const me = await API.whoami();
    USER = me.user;
    $("#login").classList.add("hidden");
    $("#app").classList.remove("hidden");
    $("#user-email").textContent = USER.email + " ("+USER.role+")";
    document.querySelectorAll(".admin-only").forEach(el=> el.classList.toggle("hidden", USER.role!=="admin"));
    document.querySelectorAll(".reviewer-only").forEach(el=> el.classList.toggle("hidden", !["reviewer","approver","admin"].includes(USER.role)));
  } catch {}
  document.querySelectorAll(".tab-btn").forEach(b=>b.addEventListener("click",()=> setTab(b.dataset.tab)));
  const enums = await API.enums();
  const causeSel = $("#cause_main");
  (enums["3-SPVP_causes_official"]?.items || enums["3-SPVP_causes"]?.items || []).forEach(item=>{
    const t = item.title || item;
    const opt = document.createElement("option"); opt.value=t; opt.textContent=t; causeSel.appendChild(opt);
  });
  const objSel = $("#object_main");
  (enums["4-SOVP_objects_official"]?.items || enums["4-SOVP_objects"]?.items || []).forEach(item=>{
    const t = item.title || item;
    const opt = document.createElement("option"); opt.value=t; opt.textContent=t; objSel.appendChild(opt);
  });
  const ssgSel = $("#nonfire_case");
  (enums["2-SSG_cases"]?.items || []).forEach(t=>{ const opt=document.createElement("option"); opt.value=t; opt.textContent=t; ssgSel.appendChild(opt); });
  toggleBlocks();
}
document.addEventListener("DOMContentLoaded", boot);
// Login
$("#btn-login").addEventListener("click", async ()=>{
  try {
    const email = $("#login-email").value.trim();
    const pass = $("#login-pass").value;
    const res = await API.login(email, pass);
    localStorage.setItem("token", res.token);
    location.reload();
  } catch(e) { alert("Ошибка входа"); }
});
$("#btn-logout").addEventListener("click", ()=>{ localStorage.removeItem("token"); location.reload(); });
// Journal
$("#incident-form").addEventListener("submit", async (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(e.target).entries());
  data.ovsr_flag = data.ovsr_flag === "true";
  data.is_residential = data.is_residential === "true";
  const r = await API.addIncident(data);
  if (r.ok) { alert("Сохранено"); $("#refresh-list").click(); }
});
$("#refresh-list").addEventListener("click", ()=> loadIncidents($("#period").value, $("#includeChildren").checked));
$("#load-incidents").addEventListener("click", ()=> loadIncidents($("#period").value, $("#includeChildren").checked));
async function loadIncidents(period, includeChildren){
  const list = await API.incidents(period, includeChildren);
  const tb = $("#inc-list tbody"); tb.innerHTML="";
  list.forEach(x=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${x.date_time||""}</td><td>${x.event_type}</td><td>${x.location_type||""}</td>
                    <td><button data-id="${x.id}" class="ghost del">Удалить</button></td>`;
    tb.appendChild(tr);
  });
  tb.querySelectorAll(".del").forEach(b=> b.addEventListener("click", async ()=>{
    await API.delIncident(b.getAttribute("data-id"));
    loadIncidents(period, includeChildren);
  }));
}
// Reports
$("#make-reports").addEventListener("click", async ()=>{
  const p = $("#period-reports").value;
  const tree = $("#tree-reports").checked;
  const rep = await API.reports(p, tree);
  $("#reports-json").textContent = JSON.stringify(rep, null, 2);
  const orgId = (window.USER||{}).org_id || "";
  $("#link-1osp").href = `/forms/1-osp?period=${encodeURIComponent(p)}&orgId=${encodeURIComponent(orgId)}&tree=${tree?'true':'false'}`;
  $("#link-3spvp").href = `/forms/3-spvp?period=${encodeURIComponent(p)}&orgId=${encodeURIComponent(orgId)}&tree=${tree?'true':'false'}`;
  $("#link-4sovp").href = `/forms/4-sovp?period=${encodeURIComponent(p)}&orgId=${encodeURIComponent(orgId)}&tree=${tree?'true':'false'}`;
});
$("#btn-validate").addEventListener("click", async ()=>{
  const p=$("#period-reports").value;
  const list = await API.validate(p);
  alert(list.length? ("Ошибок: "+list.length) : "Ошибок не найдено");
});
// Packages
$("#pkg-send").addEventListener("click", async ()=>{
  const p = $("#pkg-period").value;
  const r = await API.sendPackage(p);
  alert(r.ok? "Пакет отправлен" : "Ошибка");
});
$("#inbox-load").addEventListener("click", async ()=>{
  const p=$("#inbox-period").value;
  const list = await API.inbox(p);
  const tb = $("#pkg-table tbody"); tb.innerHTML="";
  list.forEach(x=>{
    const tr = document.createElement("tr");
    tr.innerHTML = `<td>${x.createdAt}</td><td>${x.org_id}</td><td>${x.status}</td>
      <td>
        <button class="ghost approve" data-id="${x.id}">Утвердить</button>
        <button class="ghost ret" data-id="${x.id}">Возврат</button>
      </td>`;
    tb.appendChild(tr);
  });
  tb.querySelectorAll(".approve").forEach(b=> b.addEventListener("click", async ()=>{
    await API.approve(b.getAttribute("data-id")); $("#inbox-load").click();
  }));
  tb.querySelectorAll(".ret").forEach(b=> b.addEventListener("click", async ()=>{
    const reason = prompt("Причина возврата:"); if (!reason) return;
    await API.returnPkg(b.getAttribute("data-id"), reason); $("#inbox-load").click();
  }));
});
