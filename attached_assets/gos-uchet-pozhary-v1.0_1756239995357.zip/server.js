
import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import bodyParser from "body-parser";
import cors from "cors";
import { nanoid } from "nanoid";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { createHash } from "crypto";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: "5mb" }));
app.use(express.static(path.join(__dirname, "public")));

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

const DATA_DIR = path.join(__dirname, "data");
const DB_PATH = path.join(DATA_DIR, "db.json");
const ENUM_DIR = path.join(DATA_DIR, "enums");
const SECRET = process.env.JWT_SECRET || "change_me_in_env";

function ensureFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(ENUM_DIR)) fs.mkdirSync(ENUM_DIR, { recursive: true });
  if (!fs.existsSync(DB_PATH)) {
    const adminPass = process.env.ADMIN_PASSWORD || "admin123";
    const adminHash = bcrypt.hashSync(adminPass, 10);
    const org_rk = nanoid();
    const org_region = nanoid();
    const org_district = nanoid();
    const db = {
      meta: { createdAt: new Date().toISOString() },
      orgs: [
        { id: org_rk, name: "РК", type: "rk", parentId: null, active: true },
        { id: org_region, name: "Алматинская область", type: "region", parentId: org_rk, active: true },
        { id: org_district, name: "Карасайский район", type: "district", parentId: org_region, active: true }
      ],
      users: [
        { id: nanoid(), org_id: org_rk, email: "admin@example.com", pass_hash: adminHash, role: "admin", status: "active", last_login: null }
      ],
      incidents: [],
      packages: [],
      states: [],
      audit: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8");
    console.log("[INIT] DB created. Admin: admin@example.com / " + adminPass);
  }
}
function readDB() { ensureFiles(); return JSON.parse(fs.readFileSync(DB_PATH, "utf-8")); }
function writeDB(db) { fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), "utf-8"); }
function sha(s){ return createHash("sha256").update(s).digest("hex"); }

// Auth
function requireAuth(req, res, next) {
  const token = (req.headers.authorization||"").replace("Bearer ","") || (req.cookies?.auth)||"";
  if (!token) return res.status(401).json({ ok: false, msg: "no token" });
  try {
    const payload = jwt.verify(token, SECRET);
    req.user = payload;
    next();
  } catch(e) {
    return res.status(401).json({ ok: false, msg: "bad token" });
  }
}
function requireRole(roles=[]) {
  return (req,res,next)=>{
    if (!req.user) return res.status(401).json({ ok:false });
    if (roles.length===0 || roles.includes(req.user.role)) return next();
    return res.status(403).json({ ok:false, msg:"forbidden" });
  };
}
function getOrg(db, id){ return db.orgs.find(o=>o.id===id); }
function getChildren(db, orgId){
  const result = [];
  function dfs(id){
    db.orgs.filter(o=>o.parentId===id).forEach(c=>{ result.push(c.id); dfs(c.id); });
  }
  dfs(orgId);
  return result;
}
function loadEnums() {
  const enums = {};
  if (!fs.existsSync(ENUM_DIR)) return enums;
  for (const f of fs.readdirSync(ENUM_DIR)) {
    if (f.endsWith(".json")) {
      try { enums[f.replace(".json","")] = JSON.parse(fs.readFileSync(path.join(ENUM_DIR, f), "utf-8")); }
      catch { enums[f.replace(".json","")] = { error: "parse" }; }
    }
  }
  return enums;
}
const ENUMS = loadEnums();

// Aggregation
const isCity = (t)=> t==="city_pgt";
const isRural = (t)=> t==="rural";
const sum = (a)=> a.reduce((x,y)=> x + (Number(y)||0), 0);
function aggregate(list){
  const fires = list.filter(x => ["fire","steppe_fire"].includes(x.event_type));
  const onesp = {
    counts: {
      total: fires.length,
      city_pgt: fires.filter(x=>isCity(x.location_type)).length,
      rural: fires.filter(x=>isRural(x.location_type)).length
    },
    damage_tk: sum(fires.map(x=>Number(x.loss_damage_tk||0))),
    dead_total: sum(fires.map(x=>Number(x.dead_total||0))),
    dead_kids: sum(fires.map(x=>Number(x.dead_kids||0))),
    dead_drunk: sum(fires.map(x=>Number(x.dead_drunk||0))),
    inj_total: sum(fires.map(x=>Number(x.inj_total||0))),
    inj_kids: sum(fires.map(x=>Number(x.inj_kids||0))),
    saved_people: sum(fires.map(x=>Number(x.saved_people||0))),
    saved_kids: sum(fires.map(x=>Number(x.saved_kids||0))),
    saved_values_tk: sum(fires.map(x=>Number(x.saved_values_tk||0))),
    co: {
      dead_total: sum(list.filter(x=>x.event_type==="co_nofire").map(x=>Number(x.co_dead||0))),
      inj_total: sum(list.filter(x=>x.event_type==="co_nofire").map(x=>Number(x.co_inj||0))),
      dead_kids: sum(list.filter(x=>x.event_type==="co_nofire").map(x=>Number(x.co_dead_kids||0))),
      inj_kids: sum(list.filter(x=>x.event_type==="co_nofire").map(x=>Number(x.co_inj_kids||0)))
    }
  };
  const ssg = {};
  list.filter(x=>x.event_type==="nonfire").forEach(x=>{
    const k = x.nonfire_case || "не указано";
    ssg[k] = (ssg[k]||0)+1;
  });
  const spvp = {};
  fires.forEach(x=>{
    const k = x.cause_main || "не указано";
    if (!spvp[k]) spvp[k] = { count:0, count_ovsr:0, damage_tk:0, damage_tk_ovsr:0 };
    spvp[k].count += 1; spvp[k].damage_tk += Number(x.loss_damage_tk||0);
    if (x.ovsr_flag) { spvp[k].count_ovsr += 1; spvp[k].damage_tk_ovsr += Number(x.loss_damage_tk||0); }
  });
  const sovp = {};
  fires.forEach(x=>{
    const k = x.object_main || "не указано";
    if (!sovp[k]) sovp[k] = { count:0, count_ovsr:0, damage_tk:0, damage_tk_ovsr:0 };
    sovp[k].count += 1; sovp[k].damage_tk += Number(x.loss_damage_tk||0);
    if (x.ovsr_flag) { sovp[k].count_ovsr += 1; sovp[k].damage_tk_ovsr += Number(x.loss_damage_tk||0); }
  });
  const res = fires.filter(x=>x.is_residential);
  const spzhs = { count: res.length, reasons:{}, conditions:{}, places:{}, objects:{} };
  const incF = (d,v)=>{ if(!v) return; d[v]=(d[v]||0)+1; };
  res.forEach(x=>{
    (x.res_reasons||[]).forEach(v=>incF(spzhs.reasons,v));
    (x.res_conditions||[]).forEach(v=>incF(spzhs.conditions,v));
    (x.res_places||[]).forEach(v=>incF(spzhs.places,v));
    (x.res_objects||[]).forEach(v=>incF(spzhs.objects,v));
  });
  const steppeF = list.filter(x=>x.event_type==="steppe_fire");
  const steppeZ = list.filter(x=>x.event_type==="steppe_smolder");
  const sspz = {
    table1: {
      count: steppeF.length,
      area_ga: sum(steppeF.map(x=>Number(x.steppe_area_ga||0))),
      damage_tk: sum(steppeF.map(x=>Number(x.steppe_damage_tk||0))),
      ppl_dead: sum(steppeF.map(x=>Number(x.steppe_ppl_dead||0))),
      ppl_inj: sum(steppeF.map(x=>Number(x.steppe_ppl_inj||0))),
      an_dead: sum(steppeF.map(x=>Number(x.steppe_an_dead||0))),
      an_inj: sum(steppeF.map(x=>Number(x.steppe_an_inj||0))),
      akimat_qty: sum(steppeF.map(x=>Number(x.akimat_qty||0))),
      akimat_area_ga: sum(steppeF.map(x=>Number(x.akimat_area_ga||0))),
      akimat_damage_tk: sum(steppeF.map(x=>Number(x.akimat_damage_tk||0))),
      akimat_ppl: sum(steppeF.map(x=>Number(x.akimat_ppl||0))),
      akimat_tech: sum(steppeF.map(x=>Number(x.akimat_tech||0))),
      mcs_ppl: sum(steppeF.map(x=>Number(x.mcs_ppl||0))),
      mcs_tech: sum(steppeF.map(x=>Number(x.mcs_tech||0)))
    },
    table2: {
      count: steppeZ.length,
      area_ga: sum(steppeZ.map(x=>Number(x.steppe_area_ga||0))),
      akimat_qty: sum(steppeZ.map(x=>Number(x.akimat_qty||0))),
      akimat_area_ga: sum(steppeZ.map(x=>Number(x.akimat_area_ga||0))),
      akimat_ppl: sum(steppeZ.map(x=>Number(x.akimat_ppl||0))),
      akimat_tech: sum(steppeZ.map(x=>Number(x.akimat_tech||0))),
      mcs_ppl: sum(steppeZ.map(x=>Number(x.mcs_ppl||0))),
      mcs_tech: sum(steppeZ.map(x=>Number(x.mcs_tech||0)))
    }
  };
  const validations = [];
  if (onesp.counts.total !== onesp.counts.city_pgt + onesp.counts.rural) validations.push({level:"error", code:"1-ОСП/баланс", msg:"Итого ≠ города/ПГТ + сельская"});
  if (onesp.dead_kids > onesp.dead_total) validations.push({level:"error", code:"1-ОСП/дети", msg:"Дети > погибших всего"});
  if (onesp.inj_kids > onesp.inj_total) validations.push({level:"error", code:"1-ОСП/травма", msg:"Дети > травмированных всего"});
  for (const [k,v] of Object.entries(spvp)) {
    if (v.count_ovsr > v.count) validations.push({level:"error", code:`3-СПВП/${k}`, msg:"в т.ч. ОВСР > всего"});
    if (v.damage_tk_ovsr > v.damage_tk) validations.push({level:"error", code:`3-СПВП/ущерб/${k}`, msg:"ущерб ОВСР > всего"});
  }
  for (const [k,v] of Object.entries(sovp)) {
    if (v.count_ovsr > v.count) validations.push({level:"error", code:`4-СОВП/${k}`, msg:"в т.ч. ОВСР > всего"});
    if (v.damage_tk_ovsr > v.damage_tk) validations.push({level:"error", code:`4-СОВП/ущерб/${k}`, msg:"ущерб ОВСР > всего"});
  }
  return { onesp, ssg_cases:ssg, spvp, sovp, spzhs, sspz, validations };
}

// Auth API
app.post("/api/auth/login", (req,res)=>{
  const { email, password } = req.body||{};
  const db = readDB();
  const u = db.users.find(x=>x.email===email);
  if (!u) return res.status(401).json({ ok:false, msg:"not found" });
  if (!bcrypt.compareSync(password, u.pass_hash)) return res.status(401).json({ ok:false, msg:"bad password" });
  const token = jwt.sign({ id:u.id, role:u.role, org_id:u.org_id, email:u.email }, SECRET, { expiresIn: "12h" });
  u.last_login = new Date().toISOString();
  writeDB(db);
  res.json({ ok:true, token, user:{ id:u.id, role:u.role, org_id:u.org_id, email:u.email } });
});
app.get("/api/auth/whoami", requireAuth, (req,res)=> res.json({ ok:true, user:req.user }));

// Admin: orgs & users
app.get("/api/orgs", requireAuth, (req,res)=>{ res.json(readDB().orgs); });
app.post("/api/orgs", requireAuth, requireRole(["admin"]), (req,res)=>{
  const { name, type, parentId } = req.body||{};
  const db = readDB();
  const org = { id:nanoid(), name, type, parentId: parentId||null, active:true };
  db.orgs.push(org); writeDB(db);
  res.json({ ok:true, org });
});
app.post("/api/users", requireAuth, requireRole(["admin"]), (req,res)=>{
  const { email, password, role, org_id } = req.body||{};
  const db = readDB();
  if (db.users.find(x=>x.email===email)) return res.status(400).json({ ok:false, msg:"exists" });
  const pass_hash = bcrypt.hashSync(password,10);
  const user = { id:nanoid(), email, pass_hash, role: role||"editor", org_id, status:"active", last_login:null };
  db.users.push(user); writeDB(db);
  res.json({ ok:true, user:{ id:user.id, email:user.email, role:user.role, org_id:user.org_id } });
});

// Incidents
app.get("/api/incidents", requireAuth, (req,res)=>{
  const { period, includeChildren } = req.query;
  const db = readDB();
  const myOrg = req.user.org_id;
  let orgIds = [myOrg];
  if (includeChildren==="true") orgIds = [myOrg, ...getChildren(db, myOrg)];
  let list = db.incidents.filter(x=>orgIds.includes(x.org_id));
  if (period) list = list.filter(x=>x.period===period);
  res.json(list);
});
app.post("/api/incidents", requireAuth, (req,res)=>{
  const inc = req.body||{};
  const db = readDB();
  inc.id = nanoid();
  inc.org_id = req.user.org_id;
  inc.period = (inc.date_time||"").slice(0,7);
  db.incidents.push(inc);
  db.audit.push({ id:nanoid(), ts:new Date().toISOString(), actor_user:req.user.id, org_id:req.user.org_id,
                  action:"INCIDENT_CREATE", object_type:"INCIDENT", object_id:inc.id,
                  hash: sha(JSON.stringify(inc)), prev_hash: db.audit.length? db.audit[db.audit.length-1].hash : null });
  writeDB(db);
  res.json({ ok:true, id:inc.id });
});
app.delete("/api/incidents/:id", requireAuth, (req,res)=>{
  const db = readDB();
  const idx = db.incidents.findIndex(x=>x.id===req.params.id && x.org_id===req.user.org_id);
  if (idx===-1) return res.status(404).json({ ok:false });
  const inc = db.incidents[idx];
  db.incidents.splice(idx,1);
  db.audit.push({ id:nanoid(), ts:new Date().toISOString(), actor_user:req.user.id, org_id:req.user.org_id,
                  action:"INCIDENT_DELETE", object_type:"INCIDENT", object_id:inc.id,
                  hash: sha(JSON.stringify({deleted:inc.id})), prev_hash: db.audit.length? db.audit[db.audit.length-1].hash : null });
  writeDB(db);
  res.json({ ok:true });
});

// Reports
app.get("/api/reports", requireAuth, (req,res)=>{
  const { period, orgId, tree } = req.query;
  const db = readDB();
  const baseOrgId = orgId || req.user.org_id;
  let orgIds = [baseOrgId];
  if (tree==="true") orgIds = [baseOrgId, ...getChildren(db, baseOrgId)];
  let list = db.incidents.filter(x=>orgIds.includes(x.org_id));
  if (period) list = list.filter(x=>x.period===period);
  res.json(aggregate(list));
});
app.get("/api/validate", requireAuth, (req,res)=>{
  const { period } = req.query;
  const db = readDB();
  let list = db.incidents.filter(x=>x.org_id===req.user.org_id);
  if (period) list = list.filter(x=>x.period===period);
  res.json(aggregate(list).validations);
});

// Packages
app.post("/api/packages/send", requireAuth, (req,res)=>{
  const { period } = req.body||{};
  if (!period) return res.status(400).json({ ok:false, msg:"period required" });
  const db = readDB();
  const snapshot = aggregate(db.incidents.filter(x=>x.org_id===req.user.org_id && x.period===period));
  const pkg = {
    id: nanoid(), period, level: getOrg(db, req.user.org_id).type, org_id: req.user.org_id,
    status: "sent", snapshot, createdAt: new Date().toISOString(),
    hash: sha(JSON.stringify(snapshot)), prev_hash: db.packages.length? db.packages[db.packages.length-1].hash : null
  };
  db.packages.push(pkg);
  let st = db.states.find(x=>x.org_id===req.user.org_id && x.period===period);
  if (!st) { st = { id:nanoid(), org_id:req.user.org_id, period, status:"sent", updated_at:new Date().toISOString() }; db.states.push(st); }
  else { st.status="sent"; st.updated_at=new Date().toISOString(); }
  db.audit.push({ id:nanoid(), ts:new Date().toISOString(), actor_user:req.user.id, org_id:req.user.org_id,
                  action:"PACKAGE_SEND", object_type:"PACKAGE", object_id:pkg.id,
                  hash: pkg.hash, prev_hash: db.audit.length? db.audit[db.audit.length-1].hash : null });
  writeDB(db);
  res.json({ ok:true, packageId: pkg.id });
});
app.get("/api/packages/inbox", requireAuth, requireRole(["reviewer","approver","admin"]), (req,res)=>{
  const { period } = req.query;
  const db = readDB();
  const myOrg = getOrg(db, req.user.org_id);
  const children = db.orgs.filter(o=>o.parentId===myOrg.id).map(o=>o.id);
  let list = db.packages.filter(p=>children.includes(p.org_id));
  if (period) list = list.filter(p=>p.period===period);
  res.json(list);
});
app.post("/api/packages/return", requireAuth, requireRole(["reviewer","approver","admin"]), (req,res)=>{
  const { packageId, reason } = req.body||{};
  const db = readDB();
  const pkg = db.packages.find(p=>p.id===packageId);
  if (!pkg) return res.status(404).json({ ok:false });
  pkg.status = "returned";
  db.audit.push({ id:nanoid(), ts:new Date().toISOString(), actor_user:req.user.id, org_id:req.user.org_id,
                  action:"PACKAGE_RETURN", object_type:"PACKAGE", object_id:pkg.id,
                  hash: sha(JSON.stringify({packageId,reason})), prev_hash: db.audit.length? db.audit[db.audit.length-1].hash : null,
                  meta: { reason } });
  writeDB(db);
  res.json({ ok:true });
});
app.post("/api/packages/approve", requireAuth, requireRole(["approver","admin"]), (req,res)=>{
  const { packageId } = req.body||{};
  const db = readDB();
  const pkg = db.packages.find(p=>p.id===packageId);
  if (!pkg) return res.status(404).json({ ok:false });
  pkg.status = "approved";
  let st = db.states.find(x=>x.org_id===pkg.org_id && x.period===pkg.period);
  if (st) { st.status="approved"; st.updated_at=new Date().toISOString(); }
  db.audit.push({ id:nanoid(), ts:new Date().toISOString(), actor_user:req.user.id, org_id:req.user.org_id,
                  action:"PACKAGE_APPROVE", object_type:"PACKAGE", object_id:pkg.id,
                  hash: sha(JSON.stringify({approved:pkg.id})), prev_hash: db.audit.length? db.audit[db.audit.length-1].hash : null });
  writeDB(db);
  res.json({ ok:true });
});

// Printable forms
app.get("/forms/1-osp", requireAuth, (req,res)=>{
  const { period, orgId, tree } = req.query;
  const db = readDB();
  const baseOrg = orgId || req.user.org_id;
  let orgIds = [baseOrg]; if (tree==="true") orgIds=[baseOrg, ...getChildren(db, baseOrg)];
  const list = db.incidents.filter(x=>orgIds.includes(x.org_id) && (!period || x.period===period));
  res.render("forms/1-osp", { period, org: getOrg(db, baseOrg), data: aggregate(list) });
});
app.get("/forms/3-spvp", requireAuth, (req,res)=>{
  const { period, orgId, tree } = req.query;
  const db = readDB();
  const baseOrg = orgId || req.user.org_id;
  let orgIds = [baseOrg]; if (tree==="true") orgIds=[baseOrg, ...getChildren(db, baseOrg)];
  const list = db.incidents.filter(x=>orgIds.includes(x.org_id) && (!period || x.period===period));
  res.render("forms/3-spvp", { period, org: getOrg(db, baseOrg), data: aggregate(list) });
});
app.get("/forms/4-sovp", requireAuth, (req,res)=>{
  const { period, orgId, tree } = req.query;
  const db = readDB();
  const baseOrg = orgId || req.user.org_id;
  let orgIds = [baseOrg]; if (tree==="true") orgIds=[baseOrg, ...getChildren(db, baseOrg)];
  const list = db.incidents.filter(x=>orgIds.includes(x.org_id) && (!period || x.period===period));
  res.render("forms/4-sovp", { period, org: getOrg(db, baseOrg), data: aggregate(list) });
});

// Enums
app.get("/api/enums", (req,res)=>{ 
  const enums = loadEnums();
  res.json(enums); 
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log("Started http://localhost:"+PORT));
